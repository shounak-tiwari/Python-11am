from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login as auth_login, logout as auth_logout
from django.contrib.auth.decorators import login_required
from django.contrib.auth.forms import UserCreationForm 
from django.contrib import messages

# Simple Home or Demo View
def Demo(request):
    return render(request, 'index.html')

# Register view
def register(request):
    if request.method == "POST":
        form = UserCreationForm(request.POST)
        if form.is_valid():
            form.save()
            # Optionally, add a success message
            messages.success(request, "Account created successfully!")
            return redirect('login')
        else:
            messages.error(request, "There was an error with your registration.")
    else:
        form = UserCreationForm()
    return render(request, 'reg.html', {'form': form})

# Login view (customized for demonstration, but the login view could be used here)
def login_view(request):
    if request.method == "POST":
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        if user:
            auth_login(request, user)
            return render(request, 'index.html')
        else:
            messages.error(request, "Invalid username or password.")
            return redirect('login')

    return render(request, 'login.html')


# Logout view (use Django's built-in logout view)
def logout_view(request):
    auth_logout(request)
    return redirect('main')  
