from django.urls import path
from MyApk import views

urlpatterns = [
    path('',views.Demo,name='main'),
    path('login/',views.login_view,name = 'login'),
    path('logout/',views.logout_view,name = 'logout'),
    # path('userrecord/',views.userrecord,name="userrecord"),
    path('register/',views.register,name='register'),
]